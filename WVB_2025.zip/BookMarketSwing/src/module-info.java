module ex {
    requires java.desktop;
}
