package ex;
import javax.swing.*;
import java.awt.*;

public class ex01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frame=new JFrame();
		frame.setTitle("프레임 생성1");
		frame.setSize(400,200);
		frame.setVisible(true);
	}

}
