package ex;
import javax.swing.*;
import java.awt.*;

public class ex03 extends JFrame{
	public ex03() {
		setTitle("프레임 생성 3");
		setSize(400, 200);
		setVisible(true);
		JPanel panel = new JPanel();
		panel.setBackground(Color.pink);
		add(panel);
	}
	public static void main(String args[]) {
		new ex03();
	}

}
