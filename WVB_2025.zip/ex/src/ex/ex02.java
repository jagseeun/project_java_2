package ex;
import javax.swing.*;
import java.awt.*;

public class ex02 extends JFrame{
	public ex02() {
		setTitle("프레임 생성 2");
		setSize(400,200);
		setVisible(true);
	}
	public static void main(String args[]) {
		new ex02();
	}
}
