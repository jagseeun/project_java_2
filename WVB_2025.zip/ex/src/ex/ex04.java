package ex;
import java.awt.Color;

import javax.swing.*;

public class ex04 extends JFrame{
	public ex04(){
		setTitle("프레임 아이콘");
		setSize(400,200);
		JPanel panel=new JPanel();
		panel.setBackground(Color.PINK);
		add(panel);
		setIconImage(new ImageIcon("cat.png").getImage());
		setVisible(true);
		
	}
	public static void main(String[] args ) {
		new ex04();
	}
}
